import csv
import json

CSV_PATH = "MillPoints.csv"
OUT_PATH = "mills_points.geojson"

features = []

with open(CSV_PATH, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            lat = float(row["MILL_LAT"])
            lon = float(row["MILL_LON"])
        except (KeyError, ValueError):
            continue

        # All other columns become properties
        props = dict(row)

        feat = {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [lon, lat]
            },
            "properties": props
        }
        features.append(feat)

fc = {
    "type": "FeatureCollection",
    "features": features
}

with open(OUT_PATH, "w", encoding="utf-8") as f:
    json.dump(fc, f)

print(f"Wrote {len(features)} mill points to {OUT_PATH}")
