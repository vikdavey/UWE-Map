import json
import pandas as pd

# Paths
CSV_PATH = "wood_energy_scores.csv"

# Base county file you are currently using in the map
BASE_GEOJSON = "../Real Estate/countybordersrealestateadjustableweights.geojson"

# New output file with wood/energy fields added
OUTPUT_GEOJSON = "../Real Estate/countyborders_with_woodenergy.geojson"

# 1. Load CSV and normalize FIPS to 5-character strings
df = pd.read_csv(CSV_PATH, dtype={"FIPS": str})
df["FIPS"] = df["FIPS"].str.zfill(5)

# Build lookup: FIPS -> row dict
lookup = df.set_index("FIPS").to_dict(orient="index")
print(f"Loaded {len(df)} wood/energy rows")

# 2. Load county GeoJSON
with open(BASE_GEOJSON, "r") as f:
    gj = json.load(f)

matched = 0
missing = 0

for feat in gj.get("features", []):
    props = feat.setdefault("properties", {})
    geoid = (
        props.get("GEOID")
        or props.get("geoid")
        or props.get("GEOIDFP")
    )

    if not geoid:
        missing += 1
        continue

    row = lookup.get(geoid)
    if not row:
        # No data for this county: still create keys so expressions don't break
        props["WE_Mills_Norm"]               = None
        props["WE_Energy_Norm"]              = None
        props["WE_Labor_Norm"]               = None
        props["WE_Infrastructure_Norm"]      = None
        props["WE_Infrastructure_z_Norm"]    = None
        missing += 1
        continue

    matched += 1
    props["WE_Mills_Norm"]               = float(row.get("Mills_Norm", 0))
    props["WE_Energy_Norm"]              = float(row.get("Energy_Norm", 0))
    props["WE_Labor_Norm"]               = float(row.get("Labor_Norm", 0))
    props["WE_Infrastructure_Norm"]      = float(row.get("Infrastructure_Norm", 0))
    props["WE_Infrastructure_z_Norm"]    = float(row.get("Infrastructure_z_Norm", 0))

print(f"Matched {matched} counties, missing {missing}")

with open(OUTPUT_GEOJSON, "w") as f:
    json.dump(gj, f)

print(f"Wrote updated GeoJSON to {OUTPUT_GEOJSON}")
