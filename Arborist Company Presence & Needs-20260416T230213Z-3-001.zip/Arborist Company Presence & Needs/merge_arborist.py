import json
import sys

# Increase recursion limit and memory settings for large files
sys.setrecursionlimit(20000)

# Paths
ARBORIST_GEOJSON = "arboristcompanypresence.geojson"
COUNTY_GEOJSON = "../county_core.geojson"
OUTPUT_GEOJSON = "../county_core.geojson"

# Arborist field names
ARBORIST_FIELDS = [
    "Arborist - Sheet1 (3)_Network Density",
    "Arborist - Sheet1 (3)_Canopy Cover",
    "Arborist - Sheet1 (3)_Arborist Wage"
]

print("Loading arborist data (this may take a moment for large files)...")
try:
    with open(ARBORIST_GEOJSON, "r", encoding="utf-8") as f:
        arborist_data = json.load(f)
except json.JSONDecodeError as e:
    print(f"JSON parsing error at position {e.pos}: {e.msg}")
    print("The file may be too large or have syntax errors. Trying alternative approach...")
    # Try reading in chunks or using a different method
    import gc
    gc.collect()
    # Try again with explicit parsing
    with open(ARBORIST_GEOJSON, "r", encoding="utf-8") as f:
        content = f.read()
        arborist_data = json.loads(content)
except MemoryError:
    print("File too large for available memory. Please ensure you have enough RAM.")
    sys.exit(1)

# Build lookup: GEOID -> properties
arborist_lookup = {}
for feature in arborist_data.get("features", []):
    props = feature.get("properties", {})
    geoid = props.get("GEOID")
    if geoid:
        arborist_lookup[geoid] = props

print(f"Loaded {len(arborist_lookup)} arborist records")

print("Loading county data...")
with open(COUNTY_GEOJSON, "r", encoding="utf-8") as f:
    county_data = json.load(f)

matched = 0
missing = 0

print("Merging arborist data...")
for feature in county_data.get("features", []):
    props = feature.get("properties", {})
    geoid = props.get("GEOID") or props.get("geoid")
    
    if not geoid:
        missing += 1
        # Fill with None if no GEOID
        for field in ARBORIST_FIELDS:
            props[field] = None
        continue
    
    arborist_props = arborist_lookup.get(geoid)
    if arborist_props:
        matched += 1
        # Copy arborist fields
        for field in ARBORIST_FIELDS:
            val = arborist_props.get(field)
            if val is None or val == "":
                props[field] = None
            elif isinstance(val, str):
                try:
                    props[field] = float(val)
                except (ValueError, TypeError):
                    props[field] = None
            else:
                props[field] = float(val) if val is not None else None
    else:
        missing += 1
        # Fill with None if no match
        for field in ARBORIST_FIELDS:
            props[field] = None

print(f"Matched {matched} counties, missing {missing}")

print(f"Saving merged data to {OUTPUT_GEOJSON}...")
with open(OUTPUT_GEOJSON, "w", encoding="utf-8") as f:
    json.dump(county_data, f)

print("Done! Arborist data has been merged into county_core.geojson")

