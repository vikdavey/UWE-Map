import json
import pandas as pd
import os

# --- CONFIGURATION ---
# Input filenames based on your uploaded files
REAL_ESTATE_GEOJSON = "countybordersrealestateadjustableweights.geojson" # Assumed name based on your python script
WOOD_ENERGY_CSV = "wood_energy_scores.csv"
OUTPUT_FILENAME = "final_data.geojson"

# Mappings for Real Estate (from your make_core_counties.py)
# We rename these to shorter, clean keys for the map
RE_MAPPING = {
    "Real Estate Adjustable Weights - Sheet1_Inverted Land Cost (High = Better)": "re_land",
    "Real Estate Adjustable Weights - Sheet1_Normalized Brownfield Count": "re_brownfield",
    "Real Estate Adjustable Weights - Sheet1_Normalized Exit Rate": "re_exit"
}

# Mappings for Wood Energy (from your wood_energy_scores.csv)
WE_COLUMNS = ["Mills_Norm", "Energy_Norm", "Labor_Norm"]
WE_PREFIX = "we_"

def main():
    print("--- Starting Data Prep ---")
    
    # 1. Load Real Estate GeoJSON
    if not os.path.exists(REAL_ESTATE_GEOJSON):
        print(f"ERROR: Could not find '{REAL_ESTATE_GEOJSON}'.")
        print("Please ensure your county borders file is in the same directory.")
        # Create a dummy file for demonstration if missing? No, user needs to know.
        return

    print(f"Loading {REAL_ESTATE_GEOJSON}...")
    with open(REAL_ESTATE_GEOJSON, 'r') as f:
        geojson = json.load(f)

    # 2. Load Wood Energy CSV
    if not os.path.exists(WOOD_ENERGY_CSV):
        print(f"ERROR: Could not find '{WOOD_ENERGY_CSV}'.")
        return

    print(f"Loading {WOOD_ENERGY_CSV}...")
    # Force FIPS to be string to preserve leading zeros
    df = pd.read_csv(WOOD_ENERGY_CSV, dtype={"FIPS": str})
    df["FIPS"] = df["FIPS"].str.zfill(5)
    
    # Create a lookup dictionary: FIPS -> {col: val, ...}
    we_data = df.set_index("FIPS").to_dict(orient="index")

    # 3. Merge Data
    print("Merging data...")
    matched_count = 0
    
    for feature in geojson.get("features", []):
        props = feature.get("properties", {})
        
        # Identify the FIPS/GEOID
        geoid = props.get("GEOID") or props.get("GEOIDFQ") or props.get("FIPS")
        
        if not geoid:
            continue
            
        # -- Clean Real Estate Props --
        # Extract the specific long keys and save them as short keys
        for long_key, short_key in RE_MAPPING.items():
            val = props.get(long_key)
            try:
                # Convert to float, default to 0 if missing/null
                props[short_key] = float(val) if val is not None else 0.0
            except (ValueError, TypeError):
                props[short_key] = 0.0
        
        # -- Merge Wood Energy Props --
        row = we_data.get(geoid)
        if row:
            matched_count += 1
            for col in WE_COLUMNS:
                # Create key like 'we_Mills_Norm'
                key = f"{WE_PREFIX}{col}" 
                try:
                    props[key] = float(row.get(col, 0))
                except (ValueError, TypeError):
                    props[key] = 0.0
        else:
            # Fill zeros if no data found
            for col in WE_COLUMNS:
                props[f"{WE_PREFIX}{col}"] = 0.0

        # Optional: Clean up messy original properties to save file size
        # for k in list(props.keys()):
        #     if k not in RE_MAPPING.values() and not k.startswith(WE_PREFIX) and k not in ["NAME", "GEOID", "STATEFP"]:
        #         del props[k]

    print(f"Merged Wood Energy data into {matched_count} counties.")

    # 4. Save Output
    print(f"Saving to {OUTPUT_FILENAME}...")
    with open(OUTPUT_FILENAME, 'w') as f:
        json.dump(geojson, f)
    
    print("Done! Open index.html to view the map.")

if __name__ == "__main__":
    main()