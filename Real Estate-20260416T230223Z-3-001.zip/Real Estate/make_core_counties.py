import json

SOURCE = "countybordersrealestateadjustableweights.geojson"
TARGET = "counties_core.geojson"

LAND_KEY = "Real Estate Adjustable Weights - Sheet1_Inverted Land Cost (High = Better)"
BF_KEY   = "Real Estate Adjustable Weights - Sheet1_Normalized Brownfield Count"
EXIT_KEY = "Real Estate Adjustable Weights - Sheet1_Normalized Exit Rate"

with open(SOURCE, "r") as f:
    data = json.load(f)

for feat in data["features"]:
    props = feat.get("properties", {})

    geoid   = props.get("GEOID") or props.get("GEOIDFQ")
    name    = props.get("NAME")
    statefp = props.get("STATEFP")

    new_props = {
        "geoid": geoid,
        "name": name,
        "statefp": statefp,
    }

    # map the three real-estate metrics into generic dimension 1 subscores
    mapping = [
        ("d01_s01", LAND_KEY),
        ("d01_s02", BF_KEY),
        ("d01_s03", EXIT_KEY),
    ]

    for new_key, old_key in mapping:
        val = props.get(old_key)
        if val is None:
            new_props[new_key] = None
        else:
            try:
                new_props[new_key] = float(val)
            except (ValueError, TypeError):
                new_props[new_key] = None

    feat["properties"] = new_props

with open(TARGET, "w") as f:
    json.dump(data, f)

print(f"Written cleaned counties to {TARGET}")
