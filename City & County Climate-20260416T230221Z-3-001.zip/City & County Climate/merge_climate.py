import json
import sys

# Increase recursion limit for large files
sys.setrecursionlimit(10000)

# Paths
CLIMATE_GEOJSON = "citycountyclimategoals.geojson"
COUNTY_GEOJSON = "../county_core.geojson"
OUTPUT_GEOJSON = "../county_core.geojson"

# Climate field names
CLIMATE_FIELDS = [
    "City & County Climate Goals - Sheet1_CO2 Emissions",
    "City & County Climate Goals - Sheet1_Green Infrastructure",
    "City & County Climate Goals - Sheet1_ACEEE Score",
    "City & County Climate Goals - Sheet1_Climate Mayor",
    "City & County Climate Goals - Sheet1_LEED Per Capita"
]

print("Loading climate data...")
with open(CLIMATE_GEOJSON, "r", encoding="utf-8") as f:
    climate_data = json.load(f)

# Build lookup: GEOID -> properties
climate_lookup = {}
for feature in climate_data.get("features", []):
    props = feature.get("properties", {})
    geoid = props.get("GEOID")
    if geoid:
        climate_lookup[geoid] = props

print(f"Loaded {len(climate_lookup)} climate records")

print("Loading county data...")
with open(COUNTY_GEOJSON, "r", encoding="utf-8") as f:
    county_data = json.load(f)

matched = 0
missing = 0

print("Merging climate data...")
for feature in county_data.get("features", []):
    props = feature.get("properties", {})
    geoid = props.get("GEOID") or props.get("geoid")
    
    if not geoid:
        missing += 1
        # Fill with None if no GEOID
        for field in CLIMATE_FIELDS:
            props[field] = None
        continue
    
    climate_props = climate_lookup.get(geoid)
    if climate_props:
        matched += 1
        # Copy climate fields
        for field in CLIMATE_FIELDS:
            val = climate_props.get(field)
            if val is None or val == "":
                props[field] = None
            elif isinstance(val, str):
                try:
                    props[field] = float(val)
                except (ValueError, TypeError):
                    props[field] = None
            else:
                props[field] = float(val) if val is not None else None
    else:
        missing += 1
        # Fill with None if no match
        for field in CLIMATE_FIELDS:
            props[field] = None

print(f"Matched {matched} counties, missing {missing}")

print(f"Saving merged data to {OUTPUT_GEOJSON}...")
with open(OUTPUT_GEOJSON, "w", encoding="utf-8") as f:
    json.dump(county_data, f)

print("Done! Climate data has been merged into county_core.geojson")
